# Notes
* Make sure you have Java installed
* assumes red-piraha and red-private are side by side projcts
* copy libs from [location] to fds sample
* run bat

# FDS Example
internal ei notes on how to apply Red Piranha for Financial Evaluation


# sample todo

FDS
- load in (set of rules to pull rather than named ranges)
