#! /bin/bash
echo "Running Local Rule Player"
java -jar red-player.jar
